package com.termux.app.aerochat;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.termux.R;
import com.termux.app.TermuxActivity;
import com.termux.app.activities.AiAssistantSettingsActivity;
import com.termux.terminal.TerminalSession;

/**
 * Wraps the chat-style UI ({@code view_chat_panel.xml}) around a real {@link TerminalSession}.
 * The shell underneath is completely untouched: this class only reshapes what the user types
 * and what the shell prints into chat bubbles instead of a raw scrolling grid.
 * <p>
 * Non-interactive commands (ls, pip install, cat, ...) map cleanly to one "sent" bubble and one
 * "output" bubble. Fully interactive full-screen programs (vim, htop, nano, ssh...) keep
 * streaming into a single growing bubble instead of discrete messages - for those the classic
 * terminal view (toggle button in the drawer) is still the right tool, and nothing stops the
 * user from switching back to it mid-session.
 */
public class TermuxChatController {

    private static final long SETTLE_DELAY_MS = 500;

    private final TermuxActivity mActivity;
    private final View mPanelView;
    private final ChatAdapter mAdapter;
    private final RecyclerView mRecyclerView;
    private final EditText mInputEditText;

    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Runnable mSettleRunnable = this::onOutputSettled;

    private TerminalSession mTrackedSession;
    private String mBaselineTranscript = "";
    private String mLastCommand = "";
    private ChatMessage mCurrentOutputMessage;

    public TermuxChatController(TermuxActivity activity, ViewGroup container) {
        mActivity = activity;
        mPanelView = LayoutInflater.from(activity).inflate(R.layout.view_chat_panel, container, false);
        container.addView(mPanelView);

        mRecyclerView = mPanelView.findViewById(R.id.chat_messages_recycler_view);
        mAdapter = new ChatAdapter();
        mRecyclerView.setLayoutManager(new LinearLayoutManager(activity));
        mRecyclerView.setAdapter(mAdapter);

        mInputEditText = mPanelView.findViewById(R.id.chat_input_edittext);
        ImageButton sendButton = mPanelView.findViewById(R.id.chat_send_button);
        sendButton.setOnClickListener(v -> sendCurrentInput());
        mInputEditText.setOnEditorActionListener((v, actionId, event) -> {
            sendCurrentInput();
            return true;
        });

        ImageButton aiSettingsButton = mPanelView.findViewById(R.id.chat_ai_settings_button);
        aiSettingsButton.setOnClickListener(v ->
            activity.startActivity(new Intent(activity, AiAssistantSettingsActivity.class)));

        setVisible(false);
    }

    public View getView() {
        return mPanelView;
    }

    public void setVisible(boolean visible) {
        mPanelView.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (visible) {
            TerminalSession session = mActivity.getCurrentSession();
            if (session != null) mBaselineTranscript = currentTranscript(session);
        }
    }

    public boolean isVisible() {
        return mPanelView.getVisibility() == View.VISIBLE;
    }

    private void sendCurrentInput() {
        String text = mInputEditText.getText().toString();
        if (TextUtils.isEmpty(text.trim())) return;

        TerminalSession session = mActivity.getCurrentSession();
        if (session == null || !session.isRunning()) {
            mActivity.showToast(mActivity.getString(R.string.chat_no_session_toast), true);
            return;
        }

        // Finalize whatever was still pending from a previous command before starting a new one.
        mHandler.removeCallbacks(mSettleRunnable);
        if (mCurrentOutputMessage != null) mCurrentOutputMessage.pending = false;

        mTrackedSession = session;
        mBaselineTranscript = currentTranscript(session);
        mLastCommand = text.trim();

        mAdapter.addMessage(new ChatMessage(ChatMessage.TYPE_USER, text));
        mInputEditText.setText("");

        mCurrentOutputMessage = new ChatMessage(ChatMessage.TYPE_OUTPUT, "");
        mCurrentOutputMessage.pending = true;
        mAdapter.addMessage(mCurrentOutputMessage);
        scrollToBottom();

        session.write(text + "\r");
    }

    /**
     * Forwarded from {@link com.termux.app.terminal.TermuxTerminalSessionActivityClient#onTextChanged}
     * every time the tracked session's screen buffer changes.
     */
    public void onSessionTextChanged(TerminalSession session) {
        if (!isVisible() || session != mTrackedSession || mCurrentOutputMessage == null) return;

        String current = currentTranscript(session);
        String delta = extractOutput(computeDelta(mBaselineTranscript, current), mLastCommand);
        mCurrentOutputMessage.text = delta;
        mAdapter.updateLast(mCurrentOutputMessage);
        scrollToBottom();

        mHandler.removeCallbacks(mSettleRunnable);
        mHandler.postDelayed(mSettleRunnable, SETTLE_DELAY_MS);
    }

    private void onOutputSettled() {
        if (mCurrentOutputMessage == null) return;
        mCurrentOutputMessage.pending = false;
        mAdapter.updateLast(mCurrentOutputMessage);

        String output = mCurrentOutputMessage.text;
        String command = mLastCommand;
        mCurrentOutputMessage = null;

        if (AiPreferences.isEnabled(mActivity) && !TextUtils.isEmpty(output.trim())) {
            AiAssistantClient.ask(mActivity, command, output, new AiAssistantClient.Callback() {
                @Override
                public void onResult(String text) {
                    if (!isVisible()) return;
                    mAdapter.addMessage(new ChatMessage(ChatMessage.TYPE_AI, text));
                    scrollToBottom();
                }

                @Override
                public void onError(String message) {
                    if (!isVisible()) return;
                    mActivity.showToast(mActivity.getString(R.string.ai_error_toast, message), true);
                }
            });
        }
    }

    private void scrollToBottom() {
        if (mAdapter.getItemCount() > 0) {
            mRecyclerView.scrollToPosition(mAdapter.getItemCount() - 1);
        }
    }

    private static String currentTranscript(TerminalSession session) {
        return session.getEmulator().getScreen().getTranscriptTextWithoutJoinedLines();
    }

    /** Returns whatever was appended to {@code baseline} to produce {@code current}. */
    private static String computeDelta(String baseline, String current) {
        if (current.startsWith(baseline)) return current.substring(baseline.length());
        // The screen scrolled or was cleared (e.g. "clear", a fullscreen app): fall back to the
        // longest common prefix so we still only show what is new.
        int common = 0;
        int max = Math.min(baseline.length(), current.length());
        while (common < max && baseline.charAt(common) == current.charAt(common)) common++;
        return current.substring(common);
    }

    /** Strips the shell's local echo of the command itself from the start of the captured delta. */
    private static String extractOutput(String rawDelta, String sentCommand) {
        String delta = rawDelta;
        String trimmedCommand = sentCommand == null ? "" : sentCommand.trim();
        int newlineIdx = delta.indexOf('\n');
        if (newlineIdx >= 0) {
            String firstLine = delta.substring(0, newlineIdx).trim();
            if (!trimmedCommand.isEmpty() && (firstLine.equals(trimmedCommand) || firstLine.endsWith(trimmedCommand))) {
                delta = delta.substring(newlineIdx + 1);
            }
        } else if (!trimmedCommand.isEmpty()) {
            String only = delta.trim();
            if (only.equals(trimmedCommand) || only.endsWith(trimmedCommand)) delta = "";
        }
        delta = delta.replaceFirst("^\\n+", "");
        delta = delta.replaceFirst("\\s+$", "");
        return delta;
    }
}
