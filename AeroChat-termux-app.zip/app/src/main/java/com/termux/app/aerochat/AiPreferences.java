package com.termux.app.aerochat;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Local-only storage for the optional AI assistant settings. Nothing here is ever sent
 * anywhere except to the endpoint the user themselves configured, and the whole thing can be
 * wiped at any time with {@link #clearApiKey(Context)}.
 */
public class AiPreferences {

    private static final String PREFS_NAME = "aerochat_ai_prefs";

    public static final String PROVIDER_OPENAI = "openai";
    public static final String PROVIDER_GEMINI = "gemini";

    private static final String KEY_ENABLED = "ai_enabled";
    private static final String KEY_PROVIDER = "ai_provider";
    private static final String KEY_BASE_URL = "ai_base_url";
    private static final String KEY_MODEL = "ai_model";
    private static final String KEY_API_KEY = "ai_api_key";

    public static final String DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1/chat/completions";
    public static final String DEFAULT_OPENAI_MODEL = "gpt-4o-mini";
    public static final String DEFAULT_GEMINI_MODEL = "gemini-1.5-flash";

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false) && !getApiKey(context).isEmpty();
    }

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public static String getProvider(Context context) {
        return prefs(context).getString(KEY_PROVIDER, PROVIDER_OPENAI);
    }

    public static String getBaseUrl(Context context) {
        String stored = prefs(context).getString(KEY_BASE_URL, null);
        if (stored != null && !stored.trim().isEmpty()) return stored.trim();
        return DEFAULT_OPENAI_BASE_URL;
    }

    public static String getModel(Context context) {
        String stored = prefs(context).getString(KEY_MODEL, null);
        if (stored != null && !stored.trim().isEmpty()) return stored.trim();
        return PROVIDER_GEMINI.equals(getProvider(context)) ? DEFAULT_GEMINI_MODEL : DEFAULT_OPENAI_MODEL;
    }

    public static String getApiKey(Context context) {
        String key = prefs(context).getString(KEY_API_KEY, "");
        return key == null ? "" : key;
    }

    public static void save(Context context, boolean enabled, String provider, String baseUrl, String model, String apiKey) {
        prefs(context).edit()
            .putBoolean(KEY_ENABLED, enabled)
            .putString(KEY_PROVIDER, provider)
            .putString(KEY_BASE_URL, baseUrl == null ? "" : baseUrl.trim())
            .putString(KEY_MODEL, model == null ? "" : model.trim())
            .putString(KEY_API_KEY, apiKey == null ? "" : apiKey.trim())
            .apply();
    }

    /** Wipes the stored key (and disables the assistant, since it can't work without one). */
    public static void clearApiKey(Context context) {
        prefs(context).edit()
            .putString(KEY_API_KEY, "")
            .putBoolean(KEY_ENABLED, false)
            .apply();
    }
}
