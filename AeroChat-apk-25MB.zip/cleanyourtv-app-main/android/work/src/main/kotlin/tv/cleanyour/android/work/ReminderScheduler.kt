package tv.cleanyour.android.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

// AeroClean TV, función nueva (2026-11-16): llamar a ensure(context) una vez, al arrancar la app
// (CytApplication.onCreate). ExistingPeriodicWorkPolicy.KEEP: si ya estaba programado, no lo
// reinicia en cada arranque. No pide red (la notificación solo abre la app).
object ReminderScheduler {
    private const val UNIQUE_WORK_NAME = "aeroclean_cleaning_reminder"

    fun ensure(context: Context) {
        val request = PeriodicWorkRequestBuilder<CleaningReminderWorker>(30, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build())
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(UNIQUE_WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    // Para un interruptor en Ajustes ("Avisarme cada mes"): cancelWorkByTag no sirve aquí porque el
    // trabajo es único por nombre, así que es esto.
    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
    }
}
