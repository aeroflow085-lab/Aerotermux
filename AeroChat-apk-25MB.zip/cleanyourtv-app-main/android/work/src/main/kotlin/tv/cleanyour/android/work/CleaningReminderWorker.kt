package tv.cleanyour.android.work

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.work.Worker
import androidx.work.WorkerParameters

// AeroClean TV, función nueva (2026-11-16): recordatorio mensual de limpieza. Funciona solo (no
// necesita el Graph ni una pantalla nueva), programado desde CytApplication.onCreate() vía
// ReminderScheduler. Para una v2 que avise con el nombre de la TV o se pueda apagar desde Ajustes,
// hay que leer DocumentTvRepository (:android:work ya puede usar :core:flows) y agregar el
// interruptor en AppSettingsScreen/AppSettingsMachine (eso sí toca el Graph; ver PROXIMOS-PASOS.md).
class CleaningReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val context = applicationContext
        val nm = context.getSystemService(NotificationManager::class.java) ?: return Result.success()
        ensureChannel(context, nm)

        val open = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?.apply { addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK) }
        val pi = open?.let { PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }

        val title = context.getString(R.string.work_reminder_notification_title)
        val body = context.getString(R.string.work_reminder_notification_body)

        val notification = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(NOTIFICATION_ID, notification)
        return Result.success()
    }

    private fun ensureChannel(context: Context, nm: NotificationManager) {
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val name = context.getString(R.string.work_channel_reminder_name)
        val description = context.getString(R.string.work_channel_reminder_description)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_DEFAULT).apply {
                this.description = description
                setShowBadge(false)
            },
        )
    }

    companion object {
        const val CHANNEL_ID = "cleaning_reminder"
        const val NOTIFICATION_ID = 59 // 58 es OperationService.NOTIFICATION_ID; distinto para no pisarla.
    }
}
