plugins { id("cleanyourtv.android.lib") }

dependencies {
    implementation(project(":core:engine"))
    implementation(project(":core:flows"))
    implementation(libs.kotlinx.coroutines.android)
    // AeroClean TV: recordatorio mensual (ReminderScheduler, CleaningReminderWorker). Ya permitido
    // por ModuleRules.androidCommon ("androidx.*:*"), no hace falta tocar build-logic.
    implementation(libs.androidx.work.runtime.ktx)
}
